//	if(LED4==1&&LED3==1&&LED5==1&&LED2==0&&LED1==0)  //ֱ�����
//	{	
//		go();
//		Delay(80);
//		if(LED4==0&&LED3==0&&LED5==0&&LED2==0&&LED1==0)    //ֱ��·��
//		{
//			stop();
//			Delay(100);
//			stop_left();
//			Delay(80);
//		}
//		else if((LED4==0&&LED3==0&&LED5==1&&LED2==0&&LED1==0)||(LED4==0&&LED3==1&&LED5==0&&LED2==0&&LED1==0)||(LED4==0&&LED3==0&&LED5==0&&LED2==1&&LED1==0)||(LED4==0&&LED3==1&&LED5==1&&LED2==0&&LED1==0)||(LED4==0&&LED3==0&&LED5==1&&LED2==1&&LED1==0))
//		{                                //��T
//			stop();
//			Delay(TIME);
//			stop_left();
//			Delay(200);
//		}
//	}
//	if(LED4==0&&LED3==0&&LED5==1&&LED2==1&&LED1==1)  //ֱ���ҹ�
//	{	
//		go();
//		Delay(80);
//		if(LED4==0&&LED3==0&&LED5==0&&LED2==0&&LED1==0)   //ֱ��·��
//		{
//			stop();
//			Delay(100);
//			stop_right();
//			Delay(80);
//		}
//		else if(flagc++!=1((LED4==0&&LED3==0&&LED5==1&&LED2==0&&LED1==0)||(LED4==0&&LED3==1&&LED5==0&&LED2==0&&LED1==0)||(LED4==0&&LED3==0&&LED5==0&&LED2==1&&LED1==0)||(LED4==0&&LED3==1&&LED5==1&&LED2==0&&LED1==0)||(LED4==0&&LED3==0&&LED5==1&&LED2==1&&LED1==0)))
//		{                               //��T
//			stop();
//			Delay(TIME);
//			stop_right();
//			Delay(200);
//			flagc++;
//		}
//	}
//	if((LED4==1&&LED3==1&&LED5==1&&LED2==1&&LED1==1)||(LED4==0&&LED3==1&&LED5==1&&LED2==1&&LED1==1)||(LED4==1&&LED3==1&&LED5==1&&LED2==1&&LED1==0))  //��T
//	{	
//		go();
//		speed_left=35;speed_right=35;
//		Delay(120);
//		if(LED4==0&&LED3==0&&LED5==0&&LED2==0&&LED1==0)
//		{
//			stop();
//			Delay(TIME);
//			stop_right();
//			Delay(80);
//		}
//	}
