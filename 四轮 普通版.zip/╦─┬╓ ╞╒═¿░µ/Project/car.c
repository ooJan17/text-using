#include <REGX52.H>
#include "motor.h"

extern unsigned char speed_left,speed_right;
void go()//ֱ��
{
	speed_left=22;
	speed_right=13;
	Oq_left2();
	Oq_right2();
}

void back()//����
{
	Oq_left0();
	Oq_right0();
}

void stop()//ͣ��
{
	Oq_left1();
	Oq_right1();
}

void stop_left()//ԭ����ת
{
	speed_left=50;
	speed_right=36;
	Oq_left0();
	Oq_right2();
}
void stop_leftL()//ԭ����ת
{
	speed_left=40;
	speed_right=45;
	Oq_left0();
	Oq_right2();
}

void stop_right()//ԭ����ת
{
	
	speed_left=32;
	speed_right=40;
	Oq_left2();
	Oq_right0();
}

void left()     //΢������
{
	speed_right=40;
	Oq_left1();
	Oq_right2();
}

void right()    //΢������
{
	speed_left=45;
	Oq_left2();
	Oq_right1();

}
