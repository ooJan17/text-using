#include <REGX52.H>
#include <INTRINS.H>
#include "car.h"
#include "motor.h"
#define TIME 100
#define TIME1 130

////////////////////////////////ʹ�����Ŷ���
sbit EN1A=P2^2;//����ʹ��
sbit EN1B=P2^1;//����ʹ��
////////////////////////////////

////////////////////////////////���������Ŷ���

sbit LED5=P0^4;
sbit LED4=P0^3;
sbit LED3=P0^2;
sbit LED2=P0^1;
sbit LED1=P0^0;


void Delay(unsigned int xms)		//@11.0592MHz     ������ʱ����
{
	unsigned char i, j;
while(xms)
	{		
	i = 2;
	j = 199;
	do
	{
		while (--j);	
	} while (--i);
	xms-=1;
	}
}



unsigned char counter,speed_left=20,speed_right=20,flagc=0;
unsigned int i;
void Timer0_Init()		//100??@12.000MHz         ���ö�ʱ��
{
	TMOD &= 0xF0;			
	TMOD |= 0x01;			
	TL0 = 0xA4;				
	TH0 = 0xFF;				
	TF0 = 0;				
	TR0 = 1;				
	ET0 = 1;
	EA = 1;
	PT0 = 0;
}

void Timer0_Rouyine() interrupt 1             //����PWM
{
	TL0 =0xA4;
	TH0 = 0xFF;
	counter++;
	if(counter>=100)
	{
		counter=0;
	}
	if(counter<speed_left)                 
	{
		EN1A=1;
	}
	else
	{
		EN1A=0;
	}
	if(counter<speed_right)
	{
		EN1B=1;
	}
	else
	{
		EN1B=0;
	}
}
	
void trace_TCRT5000()//��1 ��0
{
	//speed_left=29;speed_right=20;
	
//	if(LED4==0&&LED3==0&&LED5==0&&LED2==0&&LED1==1)
//		{
//			left();
//		}
//	if(LED4==1&&LED3==0&&LED5==0&&LED2==0&&LED1==0)
//		{
//			right();
//		}
		
	if((LED4==0&&LED3==1&&LED5==1&&LED2==0&&LED1==0)||(LED4==0&&LED3==1&&LED5==0&&LED2==0&&LED1==0))  //С��ƫ�� ΢��ʹ����
	{ 
		
		right();
		if(LED4==0&&LED3==0&&LED2==0&&LED1==0)
		{
			go();
//			speed_left=29;speed_right=20;
		}
	}
	if((LED4==0&&LED3==0&&LED5==0&&LED2==1&&LED1==0)||(LED4==0&&LED3==0&&LED5==1&&LED2==1&&LED1==0))  //С��ƫ�� ΢��ʹ����
	{
		left();
		if(LED4==0&&LED3==0&&LED2==0&&LED1==0)
		{
			go();
		}
	}
	if(LED1==1) //ֱ�����
	{	
		go();
		Delay(10);
		if(LED4==0&&LED3==0&&LED5==0&&LED2==0&&LED1==0)    //ֱ��·��
		{
			stop();
			Delay(50);
			while(1)
			{
				stop_left();
				if(LED1==1)
					break;
			}
			stop();
			Delay(50);
			if(LED4==0&&LED3==0&&LED5==0&&LED2==0&&LED1==0)//ȫ��
			{
					left();
					if(LED4==0&&LED3==0&&LED2==0&&LED1==0)
					{
						go();
					}
			}
		}
	
		else if((LED4==0&&LED3==1&&LED5==1&&LED2==0&&LED1==0)||(LED4==0&&LED3==0&&LED5==1&&LED2==1&&LED1==0)||(LED4==0&&LED3==0&&LED5==1&&LED2==0&&LED1==0)||(LED4==0&&LED3==0&&LED5==0&&LED2==1&&LED1==0)||(LED4==0&&LED3==1&&LED5==0&&LED2==0&&LED1==0))
		{                                //��T
			
			stop();
			Delay(50);
			while(1)
			{
				stop_left();
				if(LED1==1)
					break;
			}
			stop();
			Delay(50);
			if(LED4==0&&LED3==0&&LED5==0&&LED2==0&&LED1==0)//ȫ��
			{
					left();
					if(LED4==0&&LED3==0&&LED2==0&&LED1==0)
					{
						go();
					}
			}
		}
	}
	if(LED4==1)  //ֱ���ҹ�
	{	
		go();
		Delay(10);
		if(LED4==0&&LED3==0&&LED5==0&&LED2==0&&LED1==0)   //ֱ��·��
		{
			stop();
			Delay(50);
			while(1)
			{
				stop_right();
				if(LED4==1)
					break;
			}
			stop();
			Delay(50);
			if(LED4==0&&LED3==0&&LED5==0&&LED2==0&&LED1==0)//ȫ��
			{
					right();
					if(LED4==0&&LED3==0&&LED2==0&&LED1==0)
					{
						go();
					}
			}
		}
	
		else if(flagc==0&&((LED4==0&&LED3==1&&LED5==1&&LED2==0&&LED1==0)||(LED4==0&&LED3==0&&LED5==1&&LED2==1&&LED1==0)||(LED4==0&&LED3==0&&LED5==1&&LED2==0&&LED1==0)||(LED4==0&&LED3==0&&LED5==0&&LED2==1&&LED1==0)||(LED4==0&&LED3==1&&LED5==0&&LED2==0&&LED1==0)))
		{                               //��T
			stop();
			Delay(50);
			while(1)
			{
				stop_right();
				if(LED4==1)
					break;
			}
			stop();
			Delay(50);
			if(LED4==0&&LED3==0&&LED5==0&&LED2==0&&LED1==0)//ȫ��
			{
					right();
					if(LED4==0&&LED3==0&&LED2==0&&LED1==0)
					{
						go();
					}		
			}
			flagc+=1;
		}
	}
//		if((LED3==1&&LED5==1&&LED2==1))  //��T
//	  {	
//		  stop
//			();
//		  Delay(10);
//			if(LED4==0&&LED3==0&&LED5==0&&LED2==0&&LED1==0)
//			{
//				stop();
//				Delay(200);
//				while(1)
//			{
//				stop_right();
//				if(LED3==1)
//					break;
//			}
//			stop();
//			Delay(150);
//			if(LED4==0&&LED3==0&&LED5==0&&LED2==0&&LED1==0)//ȫ��
//			{
//					right();
//					if(LED4==0&&LED3==0&&LED2==0&&LED1==0)
//					{
//						go();
//					}
//			}
//		}
	  else if((LED4==0&&LED3==0&&LED5==1&&LED2==0&&LED1==0)||(LED4==0&&LED3==0&&LED5==0&&LED2==0&&LED1==0))
		{
			go();
		}
	
		}





void main()
{
	Timer0_Init();		//100??@12.000MHz
	go();
	while(1)
	{
	  trace_TCRT5000();
	}
	
}
